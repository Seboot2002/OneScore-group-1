-- Para resetear los contadores incrementales del ID a 1
DELETE FROM sqlite_sequence WHERE name='Genre';